Action()
{

	/* Login */

	/* Logout */

	return 0;
}